#include <stdio.h>
#include "kalman.c"

// compile : gcc ___ -o ____  -lm -lwiringPi
// the library wiringPi is included micros()

int main(void)
{
	Kalman_DATA axis;
	int i;

	reset();
	initialize();
	setRate(4);

	{
		uint8_t connection;
		fprintf(stdout,"%s\n", (connection = testConnection) ? "MPU9250 connection successful" : "MPU9250 connection failed");
		if (connection == 0)
			return 0;
	}

	for (i = 0; i < 99999; i++)
	{
		getValues(&axis);
		fprintf(stdout, "x angle: %lf\ty angle: %lf\n", axis.axis[X].angle, axis.axis[Y].angle);
	}
}

