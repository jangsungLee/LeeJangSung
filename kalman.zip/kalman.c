#include "kalman.h"

//init kalman data
void init_Kalman(_Kalman_Data *data) {
	/* We will set the varibles like so, these can also be tuned by the user */
	data->Q_angle = 0.001;
	data->Q_bias = 0.003;
	data->R_measure = 0.03;

	data->bias = 0; // Reset bias
	data->P[0][0] = 0; // Since we assume tha the bias is 0 and we know the starting angle (use setAngle), the error covariance matrix is set like so - see: http://en.wikipedia.org/wiki/Kalman_filter#Example_application.2C_technical
	data->P[0][1] = 0;
	data->P[1][0] = 0;
	data->P[1][1] = 0;
}

// Used to set angle, this should be set as the starting angle
void setAngle(_Kalman_Data *data, double newAngle)
{
	data->angle = newAngle; 
}

// Return the unbiased rate
double getRate(_Kalman_Data data)
{
	return data.rate;
}

/* These are used to tune the Kalman filter */
void setQangle(_Kalman_Data *data, double newQ_angle)
{
	data->Q_angle = newQ_angle; 
}
void setQbias(_Kalman_Data *data, double newQ_bias)
{
	data->Q_bias = newQ_bias; 
}
void setRmeasure(_Kalman_Data *data, double newR_measure) 
{
	data->R_measure = newR_measure; 
}

// The angle should be in degrees and the rate should be in degrees per second and the delta time in seconds
double getAngle(_Kalman_Data *data, double newAngle, double newRate, double dt)
{
	// KasBot V2 - Kalman filter module - http://www.x-firm.com/?page_id=145
	// Modified by Kristian Lauszus
	// See my blog post for more information: http://blog.tkjelectronics.dk/2012/09/a-practical-approach-to-kalman-filter-and-how-to-implement-it

	// Discrete Kalman filter time update equations - Time Update ("Predict")
	// Update xhat - Project the state ahead
	/* Step 1 */
	data->rate = newRate - data->bias;
	data->angle += dt * data->rate;

	// Update estimation error covariance - Project the error covariance ahead
	/* Step 2 */
	data->P[0][0] += dt * (dt*data->P[1][1] - data->P[0][1] - data->P[1][0] + data->Q_angle);
	data->P[0][1] -= dt * data->P[1][1];
	data->P[1][0] -= dt * data->P[1][1];
	data->P[1][1] += data->Q_bias * dt;

	// Discrete Kalman filter measurement update equations - Measurement Update ("Correct")
	// Calculate Kalman gain - Compute the Kalman gain
	/* Step 4 */
	data->S = data->P[0][0] + data->R_measure;
	/* Step 5 */
	data->K[0] = data->P[0][0] / data->S;
	data->K[1] = data->P[1][0] / data->S;

	// Calculate angle and bias - Update estimate with measurement zk (newAngle)
	/* Step 3 */
	data->y = newAngle - data->angle;
	/* Step 6 */
	data->angle += data->K[0] * data->y;
	data->bias += data->K[1] * data->y;

	// Calculate estimation error covariance - Update the error covariance
	/* Step 7 */
	data->P[0][0] -= data->K[0] * data->P[0][0];
	data->P[0][1] -= data->K[0] * data->P[0][1];
	data->P[1][0] -= data->K[1] * data->P[0][0];
	data->P[1][1] -= data->K[1] * data->P[0][1];

	return data->angle;
}



int getValues(Kalman_DATA *data)
{
	static double GyroRate[3];

	if (readBytes(MPU9250_ADDRESS_AD0_LOW, MPU9250_RA_ACCEL_XOUT_H, 14, data->mems.raw) != -1)
	{
		data->mems.acc[X] = ((data->mems.raw[0] << 8) | data->mems.raw[1]);
		data->mems.acc[Y] = ((data->mems.raw[2] << 8) | data->mems.raw[3]);
		data->mems.acc[Z] = ((data->mems.raw[4] << 8) | data->mems.raw[5]);
		data->mems.temp_feri = ((data->mems.raw[6] << 8) | data->mems.raw[7]);
		data->mems.gyro[X] = ((data->mems.raw[8] << 8) | data->mems.raw[9]);
		data->mems.gyro[Y] = ((data->mems.raw[10] << 8) | data->mems.raw[11]);
		data->mems.gyro[Z] = ((data->mems.raw[12] << 8) | data->mems.raw[13]);

		data->mems.temp = ((double)data->mems.temp_feri + 12412.0) / 340.0;

		data->mems.computed = 1;

		data->mems.acc_deg[X] = (atan2(data->mems.acc[Y], data->mems.acc[Z]) + M_PI) * RAD_TO_DEG;
		data->mems.acc_deg[Y] = (atan2(data->mems.acc[X], data->mems.acc[Z]) + M_PI) * RAD_TO_DEG;
		data->mems.acc_deg[Z] = (atan2(data->mems.acc[X], data->mems.acc[Y]) + M_PI) * RAD_TO_DEG;

		GyroRate[X] = (double)data->mems.gyro[X] / 131.0;
		GyroRate[Y] = -((double)data->mems.gyro[Y] / 131.0);

		data->axis[X].angle = getAngle(&data->axis[X], data->mems.acc_deg[X], GyroRate[X], (double)(micros() - Timer) / 1000000);
		data->axis[Y].angle = getAngle(&data->axis[Y], data->mems.acc_deg[Y], GyroRate[Y], (double)(micros() - Timer) / 1000000);
	}
	else
		return -1;
	return 0;
}