#include <stdio.h>
#include <math.h>
#include "MPU9250.c"

#include <wiringPi.h>

#ifndef M_PI
#define M_PI 3.14
#endif

#define PI 3.14

#ifndef RAD_TO_DEG
#define RAD_TO_DEG 57.30#endif

uint32_t Timer=0;

enum Axis {
	X = 0,
	Y = 1,
	Z = 2
};

typedef struct mems_data
{
	// X-axis, Y-axis, Z-axis
	uint8_t raw[14];;
	int16_t acc[3]; // rad
	int16_t gyro[3]; //dps (Degree Per Seconds)
	int16_t temp;
	int16_t temp_feri;
	double angle[3];
	double acc_deg[3];
	double gyro_deg[3];
	uint8_t computed;
}Mems_Data;

typedef struct kalman_data
{
	/* Kalman filter variables */
	double Q_angle; // Process noise variance for the accelerometer
	double Q_bias; // Process noise variance for the gyro bias
	double R_measure; // Measurement noise variance - this is actually the variance of the measurement noise

	double angle; // The angle calculated by the Kalman filter - part of the 2x1 state matrix
	double bias; // The gyro bias calculated by the Kalman filter - part of the 2x1 state matrix
	double rate; // Unbiased rate calculated from the rate and the calculated bias - you have to call getAngle to update the rate

	double P[2][2]; // Error covariance matrix - This is a 2x2 matrix
	double K[2]; // Kalman gain - This is a 2x1 matrix
	double y; // Angle difference - 1x1 matrix
	double S; // Estimate error - 1x1 matrix

	double KalAngle;
}_Kalman_Data;

typedef struct Kalman_data3
{
	Mems_Data mems;
	_Kalman_Data axis[3];
}Kalman_DATA;

void init_Kalman(_Kalman_Data *data);
void setAngle(_Kalman_Data *data, double newAngle);
double getRate(_Kalman_Data data);
void setQangle(_Kalman_Data *data, double newQ_angle);
void setQbias(_Kalman_Data *data, double newQ_bias);
void setRmeasure(_Kalman_Data *data, double newR_measure);
double getAngle(_Kalman_Data *data, double newAngle, double newRate, double dt);

void init_kalman_DATA(Kalman_DATA *data);

int getValue(Mems_Data *data1, _Kalman_Data *data2, int axis);
int getValues(Kalman_DATA *data);