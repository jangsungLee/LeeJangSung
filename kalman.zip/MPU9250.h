#include "MPU9250_Register_map.h"
#include "MPU9250_Register_data.h"
#include "I2Cdev.c"
#include <stdint.h> // int8_t, uint8_t , int16_t, uint16_t, int32_t, uint32_t



#ifndef _MPU9250_H_
#define _MPU9250_H_

typedef struct mpu_data
{
	int handle;
	uint8_t buffer[14];
}MPU_DATA;

#define MIN(A,B) A<B?A:B

#define MPU9250_DMP_CODE_SIZE       1962    // dmpMemory[]
#define MPU9250_DMP_CONFIG_SIZE     232     // dmpConfig[]
#define MPU9250_DMP_UPDATES_SIZE    140     // dmpUpdates[]

MPU_DATA i2c_data = {MPU9250_ADDRESS_AD0_LOW,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

uint8_t *dmpPacketBuffer;
uint16_t dmpPacketSize;


void setClockSource(uint8_t source);

void setFullScaleGyroRange(uint8_t range);
void setFullScaleAccelRange(uint8_t range);

void setSleepEnabled(uint8_t enabled);

void initialize();
uint8_t testConnection();
uint8_t getDeviceID();

void reset();

void setMemoryBank(uint8_t bank, uint8_t prefetchEnabled, uint8_t userBank);
void setMemoryStartAddress(uint8_t address);
uint8_t readMemoryByte();

uint8_t getOTPBankValid();

void setXAccelOffset(int16_t offset);
void setYAccelOffset(int16_t offset);
void setZAccelOffset(int16_t offset);

int8_t getXGyroOffset();
int8_t getYGyroOffset();
int8_t getZGyroOffset();

void setIntEnabled(uint8_t enabled);
uint8_t getIntStatus();

void setI2CBypassEnabled(uint8_t enabled);

void setRate(uint8_t rate);
void setDLPFMode(uint8_t mode);
void setExternalFrameSync(uint8_t sync);
void setFullScaleGyroRange(uint8_t range);

void setDMPConfig1(uint8_t config);
void setDMPConfig2(uint8_t config);
void setOTPBankValid(uint8_t enabled);

void setXGyroOffset(int8_t offset);
void setYGyroOffset(int8_t offset);
void setZGyroOffset(int8_t offset);

void setXGyroOffsetUser(int16_t offset);
void setYGyroOffsetUser(int16_t offset);
void setZGyroOffsetUser(int16_t offset);

void setMotionDetectionThreshold(uint8_t threshold);
void setZeroMotionDetectionThreshold(uint8_t threshold);
void setMotionDetectionDuration(uint8_t duration);
void setZeroMotionDetectionDuration(uint8_t duration);

uint16_t getFIFOCount();
void getFIFOBytes(uint8_t *data, uint8_t length);
void resetFIFO();

uint16_t dmpGetFIFOPacketSize();

void setDMPEnabled(uint8_t enabled);
int WriteMemoryBlock(uint8_t *data, uint16_t dataSize, uint8_t bank, uint8_t address);
int writeDMPConfigurationSet(uint8_t *data, uint16_t dataSize, uint8_t bank, uint8_t address);
uint8_t dmpInitialize();

#endif  /*_MPU9250_H_*/
